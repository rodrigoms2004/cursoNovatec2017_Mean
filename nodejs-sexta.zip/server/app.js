// server/app.js

'use strict';

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const debug = require('debug')('sexta:server:app');
const nunjucks = require('nunjucks');
const session = require('express-session')



app.use(session({
  secret: 'novatec secret',
  resave: false,
  saveUninitialized: true,
  cookie: {
    secure: false, // https
    maxAge: 1000 * 60 * 60
  }
}))


app.set('view engine', 'html');

nunjucks.configure(__dirname + '/views', {
  autoescape: true,
  express: app,
  tags: ''
});


global.APP_ROOT = require('path').join(__dirname + '/../');
app.use(express.static(APP_ROOT + '/public'));


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function(request, response, next) {
  console.log('passei por aqui: ', request.url);
  next();
});
app.use('/', require('./route'));


app.use(function(request, response, next) {
  let err = new Error('não existe');
  err.status = 404;
  next(err);
});
app.use(function(err, request, response, next) {
  // elvis operator

  // logger.err('...')
  response.status(err.status || 500).send(err.message || 'deu ruim');
});


module.exports = app;





