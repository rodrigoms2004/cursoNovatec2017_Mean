// server/route/index.js

'use strict';

const ROUTER = require('express').Router();
const MainController = require('../controller/MainController');

// http://localhost:3000/
ROUTER.get('/', MainController.home);

// Postman
// curl -X POST http://localhost:3000
ROUTER.get('/login', MainController.create);
ROUTER.get('/products', MainController.listProducts);

ROUTER.use('/api', require('./api'));


module.exports = ROUTER;


// module.exports = {
//   ROUTER: ROUTER,
//   b: 42
// };
