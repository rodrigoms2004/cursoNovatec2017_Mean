// server/repository/ProductRepository.js
'use strict';

const db = require('../config/mongo');

let ProductRepository = {
  find: (query, callback) => { //bind this
    // db.query('SELECT * FROM table', callback);
    // assincrono
    db.collection('products').find(query, callback);
  },
  //quando eu fiz esse código, só eu e Deus sabíamos, agora só Deus.
  findOne: function(query, callback) {
    if (query._id){
      query._id = db.ObjectId(query._id);
    }

    db.collection('products').findOne(query, callback);
  },
  //NAO MEXA
  insert(data, callback) {
    db.collection('products').insert(data, callback);
  },
  //eu não tive coragem de mexer
  update: (query, data, callback) => {
    if (query._id){
      query._id = db.ObjectId(query._id);
    }

    db.collection('products').update(query, { $set: data }, callback);
  },
  remove: (query, callback) => {
    if (query._id){
      query._id = db.ObjectId(query._id);
    }

    db.collection('products').remove(query, callback);
  }
};

module.exports = ProductRepository;
