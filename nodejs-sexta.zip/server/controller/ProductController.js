// server/controller/ProductController.js
'use strict';

const bluebird = require('bluebird');
const repository = bluebird.promisifyAll(require('../repository/ProductRepository'));

const debug = require('debug')('sexta:controller:product');

// JSON VIEW

// /api/products?name=sh

let ProductController = {
  list: function(request, response, next) {
    let query = {};
    if (request.query.name) {
      query.name = new RegExp(request.query.name, 'i');
    }

    // request.headers.token

    debug('request.session.user', request.session.user)

    repository.findAsync(query)
      .then(data => response.json(data))
      .catch(next);
  },
  // /api/products/42?ab=wbruno
  byId: function(request, response, next) {
    let id = request.params.id;
    repository.findOneAsync({ _id: id })
      .then((data) => {
        response.json(data);
      })
      .catch(next);
  },

  create: function(request, response, next) {
    let body = request.body;
    repository.insert(body, (err, data) => {
      if(err) {
        return next(err);
      }

      response.status(201).json(data);
    })
  },
  update: function(request, response, next) {
    let body = request.body;
    let id = request.params.id;

    repository.update({ _id: id }, body, (err, data)=> {
      if(err) {
        return next(err);
      }
      response.json(data);
      // response.redirect(301, '/api/old');
    });
  },
  delete: function(request, response, next) {
    let id = request.params.id;

    repository.remove({ _id: id }, (err, data) => {
      if(err) {
        return next(err);
      }

      if(data.n > 0) {
        response.sendStatus(204);
      } else {
        response.status(404).send('não há nada para deletar');
      }
    })

  }
};

module.exports = ProductController;
