'use strict';

const db = require('../config/mongo');
const debug = require('debug')('sexta:controller:auth');

let AuthController = {
  login: function(request, response, next) {
    let query = {
      user: request.body.user,
      pass: request.body.pass
    };

    debug('query', query);

    db.collection('users').findOne(query, function(err, data) {
      if(err) {
        return next(err);
      }
      if(data && data.name) {
        request.session.user = data;
        debug('data---->', data);
        response.redirect(301, '/api/products');
      } else {
        response.sendStatus(401);
      }
    })
  }
};

module.exports = AuthController;
