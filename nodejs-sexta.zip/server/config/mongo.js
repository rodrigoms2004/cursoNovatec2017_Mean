// server/config/mongo.js
'use strict';

const debug = require('debug')('sexta:config:mongo');
const mongojs = require('mongojs');

let database = process.env.NODE_ENV == 'test' ? 'curso-sexta-test' : 'curso-sexta';

let db = mongojs(`localhost:27017/${database}`);
// let db = mongojs('localhost:27017/' + database);

module.exports = db;


