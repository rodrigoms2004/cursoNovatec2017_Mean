//test.js
// RedeCT1 - ctntrede1


console.log('Hello Novatec\n');


