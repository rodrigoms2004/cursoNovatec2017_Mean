// test/nodejs/main.test.js
'use strict';

const app = require('../../server/app');
const request = require('supertest')(app);
const assert = require('assert');


// RABBIT MQ
describe('main tests', ()=> {
  it('GET / should respond 200', (done)=> { //arrow function
    request
      .get('/')
      .end(function(err, result) {
        assert.ok(!err);
        assert.equal(200, result.status);
        done();
      });
  });

  it('GET /not-found respond 404', (done) => {
    request
      .get('/not-found')
      .end(function(err, result) {
        assert.equal(404, result.status);
        assert.equal('não existe', result.text);
        done();
      });
  });

  it.skip('GET /api respond PING', () => {

  });
});
